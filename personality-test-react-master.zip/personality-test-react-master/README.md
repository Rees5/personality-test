# React Personality Test

This demo is one of my project for my class in Lasalle College / Montreal<br>
I followed this tutorial [mitchgaven/react-multi-choice-quiz](https://mitchgavan.github.io/react-multi-choice-quiz/)<br>
After I altered it to created this applicaiton.

The design is mainly inspired by this great post from [Lubos in Codepen](https://codepen.io/lmenus/pen/KrEqpG)

[View demo](https://irfanabliz.github.io/personality-test-react/)

Created with [Create React App](https://github.com/facebookincubator/create-react-app)
